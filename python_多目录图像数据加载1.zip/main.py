
import tensorflow as tf
from sklearn.metrics import f1_score, recall_score, precision_score
from tensorflow.keras.callbacks import Callback, ReduceLROnPlateau
import numpy as np
from data_loader import MultiDirectoryDataLoader
from model import FerModel
import os

class Metrics(Callback):

    aa=0
    model=None
    validation_data = None
    def on_train_begin(self, logs={}):
        self.val_f1s = []
        self.val_recalls = []
        self.val_precisions = []

    def on_epoch_end(self, epoch, logs=None):

        val_predict = (np.asarray(self.model.predict(self.model.validation_data[0]))).round()
        val_targ = self.model.validation_data[1]


        _val_f1 = f1_score(val_targ, val_predict,average='macro')
        if logs is not None:
            val_accuracy = logs.get('val_accuracy')
            if val_accuracy is not None and val_accuracy>=0.9566 and val_accuracy>Metrics.aa:
                # print(f"Epoch {epoch + 1}: Validation Accuracy = {val_accuracy:.4f}")
                fer_json = self.model.to_json()
                with open("bestParam.json", "w") as json_file:
                    json_file.write(fer_json)
                self.model.save_weights("bestParam.h5")
                Metrics.aa = val_accuracy
                print(Metrics.aa)
                print("Saved model to disk")

        _val_recall = recall_score(val_targ, val_predict,average='macro')
        _val_precision = precision_score(val_targ, val_predict,average='macro')
        self.val_f1s.append(_val_f1)
        self.val_recalls.append(_val_recall)
        self.val_precisions.append(_val_precision)
        print (" — val_f1: % f — val_precision: % f — val_recall % f" % (_val_f1, _val_precision, _val_recall))
        return

class Main(object):
    def __init__(self):
        self.x_shape = (224, 224,3)
        self.epoch = 100
        self.batchsize = 16
        self.weight_decay = 0.0005
        self.classes = 10
        self.validation_data = None
        self.model = self.build_model()
        self.train = self.train()

# 99.95 99.95
        # self.show_history()
    def build_model(self):
        # 创建模型
        print("创建模型...")
        fermodel = FerModel()
        model = fermodel.model
        return model

    def train(self):
        """主函数"""
        print("TensorFlow版本:", tf.__version__)

        # 配置参数
        dir1 = "D:\\数据集\\100-Driver\\Day\\Cam1"  # 第一个分支数据目录
        dir2 = "D:\\数据集\\100-Driver\\Day\\Cam2"  # 第二个分支数据目录
        dir3 = "D:\\数据集\\100-Driver\\Day\\Cam3"  # 第二个分支数据目录
        dir4 = "D:\\数据集\\100-Driver\\Day\\Cam4"  # 第二个分支数据目录
        img_size1 = (224, 224, 3)
        img_size2 = (224, 224, 3)
        img_size3 = (224, 224, 3)
        img_size4 = (224, 224, 3)
        batch_size = 16
        epochs = 100


        # 创建多目录数据加载器
        print("创建多目录数据加载器...")
        sample = 2000
        train_generator = MultiDirectoryDataLoader(
            dir1=dir1,
            dir2=dir2,
            dir3=dir3,
            dir4=dir4,
            batch_size=batch_size,
            sampleNum=sample,
            img_size1=img_size1[:2],
            img_size2=img_size2[:2],
            img_size3=img_size3[:2],
            img_size4=img_size4[:2],
            shuffle=True,
            is_training=True
        )

        val_generator = MultiDirectoryDataLoader(
            dir1=dir1,
            dir2=dir2,
            dir3=dir3,
            dir4=dir4,
            batch_size=batch_size,
            sampleNum = sample,
            img_size1=img_size1[:2],
            img_size2=img_size2[:2],
            img_size3=img_size3[:2],
            img_size4=img_size4[:2],
            shuffle=False,
            is_training=False
        )

        # 获取类别信息
        num_classes = train_generator.get_num_classes()
        class_names = train_generator.get_class_names()
        print(f"发现 {num_classes} 个类别: {class_names}")

        if num_classes < 2:
            print("错误: 类别数少于2个，请检查数据目录结构")
            return

        # model.summary()
        # 设置回调
        callbacks = [
            tf.keras.callbacks.EarlyStopping(
                monitor='val_loss',
                patience=100,
                restore_best_weights=True
            ),
            tf.keras.callbacks.ReduceLROnPlateau(
                monitor='val_accuracy',  # 监控验证损失
                factor=0.2,  # 学习率下降因子
                mode="max",
                verbose=1,
                patience=3,  # 3轮未改善则触发
                min_lr=1e-6  # 最小学习率
            ),
            # tf.keras.callbacks.ReduceLROnPlateau(
            #     monitor='val_loss',
            #     factor=0.5,
            #     patience=3,
            #     min_lr=1e-7
            # ),
            tf.keras.callbacks.ModelCheckpoint(
                '97.80.h5',
                monitor='val_accuracy',
                save_best_only=True,
                mode='max'
            )
        ]
        # 创建Momentum优化器
        momentum_optimizer = tf.keras.optimizers.SGD(learning_rate=0.0015, momentum=0.95)
        self.model.compile(optimizer=momentum_optimizer,
                           loss='categorical_crossentropy',  # 损失函数
                           metrics=['accuracy'])  # 指标
        # training the model
        metrics = Metrics()
        self.model.validation_data = MultiDirectoryDataLoader.valData

        # 训练模型
        print("开始流式训练...")
        history = self.model.fit(
            train_generator,
            epochs=epochs,
            validation_data=val_generator,
            callbacks=[callbacks],
            verbose=1,
            shuffle=True
        )

        # 保存最终模型
        self.model.save('final_model.h5')
        print("模型训练完成并已保存!")

        # 显示训练结果
        best_val_acc = max(history.history['val_accuracy'])
        print(f"最佳验证准确率: {best_val_acc:.4f}")



if __name__ == "__main__":
    Main()
