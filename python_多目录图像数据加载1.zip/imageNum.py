import os
from collections import defaultdict


def count_images_in_subfolders(root_dirs):
    """
    统计指定目录下各子文件夹中的图片数量

    Args:
        root_dirs: 包含四个目录路径的列表

    Returns:
        dict: 每个目录及其子文件夹图片统计结果
    """
    # 支持的图片格式
    image_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.webp'}

    # 存储结果
    results = {}

    # 遍历每个根目录
    for root_dir in root_dirs:
        if not os.path.exists(root_dir):
            print(f"警告: 目录 '{root_dir}' 不存在")
            results[root_dir] = {}
            continue

        folder_counts = defaultdict(int)

        # 遍历根目录下的所有子文件夹
        try:
            for item in os.listdir(root_dir):
                item_path = os.path.join(root_dir, item)

                # 只处理目录
                if os.path.isdir(item_path):
                    image_count = 0

                    # 遍历子文件夹中的所有文件
                    for file in os.listdir(item_path):
                        file_path = os.path.join(item_path, file)

                        # 检查是否为图片文件
                        if os.path.isfile(file_path):
                            _, ext = os.path.splitext(file.lower())
                            if ext in image_extensions:
                                image_count += 1

                    folder_counts[item] = image_count

        except PermissionError:
            print(f"权限错误: 无法访问目录 '{root_dir}'")
            results[root_dir] = {}
            continue

        results[root_dir] = dict(folder_counts)

    return results


def display_results(results):
    """
    显示统计结果

    Args:
        results: 统计结果字典
    """
    print("=" * 60)
    print("图片统计结果")
    print("=" * 60)

    total_all_images = 0

    for root_dir, folder_counts in results.items():
        print(f"\n目录: {root_dir}")
        print("-" * 40)

        if not folder_counts:
            print("  无子文件夹或访问失败")
            continue

        total_images = sum(folder_counts.values())
        total_all_images += total_images

        # 按图片数量降序排列
        sorted_folders = sorted(folder_counts.items(), key=lambda x: x[1], reverse=True)

        for folder, count in sorted_folders:
            print(f"  {folder}: {count} 张图片")

        print(f"  小计: {total_images} 张图片")

    print("\n" + "=" * 60)
    print(f"总计: {total_all_images} 张图片")
    print("=" * 60)


def save_results_to_file(results, output_file="image_statistics.txt"):
    """
    将统计结果保存到文件

    Args:
        results: 统计结果字典
        output_file: 输出文件名
    """
    try:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("图片统计结果\n")
            f.write("=" * 60 + "\n")

            total_all_images = 0

            for root_dir, folder_counts in results.items():
                f.write(f"\n目录: {root_dir}\n")
                f.write("-" * 40 + "\n")

                if not folder_counts:
                    f.write("  无子文件夹或访问失败\n")
                    continue

                total_images = sum(folder_counts.values())
                total_all_images += total_images

                # 按图片数量降序排列
                sorted_folders = sorted(folder_counts.items(), key=lambda x: x[1], reverse=True)

                for folder, count in sorted_folders:
                    f.write(f"  {folder}: {count} 张图片\n")

                f.write(f"  小计: {total_images} 张图片\n")

            f.write("\n" + "=" * 60 + "\n")
            f.write(f"总计: {total_all_images} 张图片\n")
            f.write("=" * 60 + "\n")

        print(f"结果已保存到 '{output_file}'")

    except Exception as e:
        print(f"保存文件时出错: {e}")


def main():
    """
    主函数
    """
    # 示例目录路径，请根据实际情况修改
    directories = [
        "D:\\数据集\\100-Driver\\Day\\Cam1",
        "D:\\数据集\\100-Driver\\Day\\Cam2",
        "D:\\数据集\\100-Driver\\Day\\Cam3",
        "D:\\数据集\\100-Driver\\Day\\Cam4",
    ]

    print("图片统计工具")
    print("支持的图片格式: jpg, jpeg, png, gif, bmp, tiff, webp")

    # 用户输入目录路径
    user_directories = []
    print("\n请输入4个目录路径:")
    for i in range(4):
        while True:
            path = input(f"目录{i + 1}: ").strip()
            if path:
                user_directories.append(path)
                break
            else:
                print("路径不能为空，请重新输入")

    # 统计图片数量
    print("\n正在统计图片数量...")
    results = count_images_in_subfolders(user_directories)

    # 显示结果
    display_results(results)

    # 询问是否保存结果
    save_choice = input("\n是否将结果保存到文件? (y/n): ").strip().lower()
    if save_choice in ['y', 'yes']:
        output_filename = input("请输入输出文件名 (默认: image_statistics.txt): ").strip()
        if not output_filename:
            output_filename = "image_statistics.txt"
        save_results_to_file(results, output_filename)


if __name__ == "__main__":
    main()
