

import cv2
from sklearn.metrics import f1_score, recall_score, accuracy_score, precision_score
from tensorflow.keras.layers import Conv2D, MaxPooling2D, DepthwiseConv2D, GlobalAveragePooling2D, Dense, PReLU, Input, \
    BatchNormalization, GlobalMaxPooling2D, SeparableConv2D, LeakyReLU, Concatenate,Lambda,Flatten,SeparableConvolution2D
from tensorflow.keras.models import Model
from tensorflow.keras import regularizers, layers, models
from tensorflow.keras.callbacks import ModelCheckpoint, ReduceLROnPlateau, TensorBoard, EarlyStopping
from tensorflow.keras.layers import Activation, Dropout, Flatten, AveragePooling2D, add
from matplotlib import pyplot as plt
import tensorflow as tf
from tensorflow.keras.optimizers import Adam, SGD
from tensorflow.keras import regularizers
import os
import numpy as np
import warnings
import time
import tensorflow.keras.layers
from tensorflow.keras.applications.efficientnet import EfficientNetB7
import sklearn
import seaborn as sns
from tensorflow.keras.applications.mobilenet import MobileNet
from tensorflow.keras.callbacks import Callback
from tensorflow.keras.layers import concatenate, Conv2DTranspose, ZeroPadding2D, multiply, UpSampling2D, Add, \
    ReLU, MaxPool2D, Reshape, GlobalAvgPool2D, Multiply
from tensorflow.keras import backend as K
from tensorflow.python.keras.applications.efficientnet import EfficientNetB0
from tensorflow.python.keras.applications.resnet import ResNet50


class Metrics(Callback):

    aa=0
    def on_train_begin(self, logs={}):
        self.val_f1s = []
        self.val_recalls = []
        self.val_precisions = []

    def on_epoch_end(self, epoch, logs=None):
        val_predict = (np.asarray(self.model.predict(self.model.validation_data[0]))).round()
        val_targ = self.model.validation_data[1]
        _val_f1 = f1_score(val_targ, val_predict,average='macro')
        if logs is not None:
            val_accuracy = logs.get('val_accuracy')
            if val_accuracy is not None and val_accuracy>=0.9566 and val_accuracy>Metrics.aa:
                # print(f"Epoch {epoch + 1}: Validation Accuracy = {val_accuracy:.4f}")
                fer_json = self.model.to_json()
                with open("bestParam.json", "w") as json_file:
                    json_file.write(fer_json)
                self.model.save_weights("bestParam.h5")
                Metrics.aa = val_accuracy
                print(Metrics.aa)
                print("Saved model to disk")

        _val_recall = recall_score(val_targ, val_predict,average='macro')
        _val_precision = precision_score(val_targ, val_predict,average='macro')
        self.val_f1s.append(_val_f1)
        self.val_recalls.append(_val_recall)
        self.val_precisions.append(_val_precision)
        print (" — val_f1: % f — val_precision: % f — val_recall % f" % (_val_f1, _val_precision, _val_recall))
        return
import uuid
# 用于避免卷积层同名报错
unique_random_number = uuid.uuid4()

from tensorflow import keras
def swin_mlp_block(x, dim, window_size=7, mlp_ratio=4):
    """Window-MLP block: LayerNorm → Window partition → MLP → reverse window → Add"""
    B, H, W, C = x.shape[0], x.shape[1], x.shape[2], x.shape[3]
    shortcut = x
    x = layers.LayerNormalization(epsilon=1e-5)(x)

    # Pad to multiple of window_size
    pad_h = (window_size - H % window_size) % window_size
    pad_w = (window_size - W % window_size) % window_size
    x = layers.ZeroPadding2D(((0, pad_h), (0, pad_w)))(x)
    _, Hp, Wp, _ = x.shape

    # Reshape into windows (B, Nw, window_size, window_size, C)
    x = layers.Reshape((Hp // window_size, window_size,
                        Wp // window_size, window_size, C))(x)
    x = tf.transpose(x, perm=[0, 1, 3, 2, 4, 5])  # (B, H/w, W/w, w, w, C)
    x = layers.Reshape((-1, window_size * window_size, C))(x)  # (B*Nw, w*w, C)

    # MLP along spatial dimension
    x = layers.Dense(window_size * window_size, activation='gelu')(x)
    x = layers.Dense(C)(x)

    # Restore spatial shape
    x = layers.Reshape((Hp // window_size, Wp // window_size,
                        window_size, window_size, C))(x)
    x = tf.transpose(x, perm=[0, 1, 3, 2, 4, 5])
    x = layers.Reshape((Hp, Wp, C))(x)
    # Remove padding
    if pad_h > 0 or pad_w > 0:
        x = layers.Cropping2D(((0, pad_h), (0, pad_w)))(x)

    # Channel MLP
    x = layers.LayerNormalization(epsilon=1e-5)(x)
    x = layers.Dense(int(dim * mlp_ratio), activation='gelu')(x)
    x = layers.Dense(dim)(x)
    return layers.Add()([shortcut, x])
# 1. 超参数
IMG_SIZE   = 224          # CIFAR-10 可设 32；若 224 会自动 resize
BATCH_SIZE = 128
EPOCHS     = 200
NUM_CLASS  = 10
MIXUP_ALPHA= 0.2
class TransformerBlock(layers.Layer):
    def __init__(self, embed_dim, num_heads, ff_dim, rate=0.1):
        super(TransformerBlock, self).__init__()
        self.att = layers.MultiHeadAttention(num_heads=num_heads, key_dim=embed_dim)
        self.ffn = tf.keras.Sequential([
            layers.Dense(ff_dim, activation="relu"),
            layers.Dense(embed_dim)
        ])
        self.layernorm1 = layers.LayerNormalization(epsilon=1e-6)
        self.layernorm2 = layers.LayerNormalization(epsilon=1e-6)
        self.dropout1 = layers.Dropout(rate)
        self.dropout2 = layers.Dropout(rate)

    def call(self, inputs, training):
        attn_output = self.att(inputs, inputs)
        attn_output = self.dropout1(attn_output, training=training)
        out1 = self.layernorm1(inputs + attn_output)
        ffn_output = self.ffn(out1)
        ffn_output = self.dropout2(ffn_output, training=training)
        return self.layernorm2(out1 + ffn_output)
def mobilenet_block(x, filters, kernel_size, strides=1):
    """
    MobileNet Block: Depthwise Convolution + Pointwise Convolution
    """
    input_channels = x.shape[-1]
    # x = layers.DepthwiseConv2D(kernel_size, strides=strides, padding='same', use_bias=False)(x)
    # x = layers.BatchNormalization()(x)
    # x = layers.ReLU()(x)
    # x = layers.Conv2D(filters, 1, padding='same', use_bias=False)(x)
    # x = layers.BatchNormalization()(x)
    # x = layers.ReLU()(x)

    x = layers.Conv2D(filters, 3,padding="same",  use_bias=False)(x)
    x = layers.BatchNormalization()(x)
    x = layers.ReLU()(x)
    x = MaxPooling2D(pool_size=(2,2))(x)

    x = layers.Conv2D(filters, 5,padding="same", use_bias=False)(x)
    x = layers.BatchNormalization()(x)
    x = layers.ReLU()(x)
    x = MaxPooling2D(pool_size=(2,2))(x)

    x = layers.Conv2D(filters, 7,padding="same",  use_bias=False)(x)
    x = layers.BatchNormalization()(x)
    x = layers.ReLU()(x)
    x = MaxPooling2D(pool_size=(2,2))(x)

    return x

def convnext_block(x, filters):
    """
    ConvNeXt Block: Depthwise Convolution + LayerNorm + MLP
    """
    # Ensure the number of groups matches the number of input channels
    input_channels = x.shape[-1]
    x = layers.Conv2D(input_channels, kernel_size=7, padding='same', groups=input_channels)(x)
    x = layers.LayerNormalization(epsilon=1e-6)(x)
    x = layers.Dense(4 * filters, activation='gelu')(x)
    x = layers.Dense(filters)(x)
    return x

def efficientnet_block(x, filters, kernel_size, strides=1, expand_ratio=6):
    """
    EfficientNet Block: MBConv Block with Swish activation
    """
    input_channels = x.shape[-1]
    expanded_channels = input_channels * expand_ratio
    if expand_ratio > 1:
        x = layers.Conv2D(expanded_channels, 1, padding='same', use_bias=False)(x)
        x = layers.BatchNormalization()(x)
        x = layers.Activation('relu')(x)

    x = layers.DepthwiseConv2D(kernel_size, strides=strides, padding='same', use_bias=False)(x)
    x = layers.BatchNormalization()(x)
    x = layers.Activation('relu')(x)

    x = layers.Conv2D(filters, 1, padding='same', use_bias=False)(x)
    x = layers.BatchNormalization()(x)

    if strides == 1 and input_channels == filters:
        x = layers.Add()([x, layers.Conv2D(filters, 1, padding='same', use_bias=False)(x)])
    return x

IMAGE_ORDERING = 'channels_last'

class FerModel(object):
    def __init__(self):
        self.x_shape = (224, 224,3)
        self.epoch = 100
        self.batchsize = 16
        self.weight_decay = 0.0005
        self.classes = 10
        self.model = self.create_multi_directory_model()

    def ca_block(self,input_feature, ratio=16, name=""):
        channel = input_feature.shape[-1]
        h = input_feature.shape[1]
        w = input_feature.shape[2]

        x_h = Lambda(lambda x: K.mean(x, axis=2, keepdims=True))(input_feature)
        x_h = Lambda(lambda x: K.permute_dimensions(x, [0, 2, 1, 3]))(x_h)
        x_w = Lambda(lambda x: K.max(x, axis=1, keepdims=True))(input_feature)

        x_cat_conv_relu = Concatenate(axis=2)([x_w, x_h])
        x_cat_conv_relu = Conv2D(channel // ratio, kernel_size=1, strides=1, use_bias=False,
                                 name="ca_block_conv1_" +str(uuid.uuid4())+ str(name))(x_cat_conv_relu)
        x_cat_conv_relu = BatchNormalization(name="ca_block_bn_" +str(uuid.uuid4())+ str(name))(x_cat_conv_relu)
        x_cat_conv_relu = Activation('relu')(x_cat_conv_relu)

        x_cat_conv_split_h, x_cat_conv_split_w = Lambda(lambda x: tf.split(x, num_or_size_splits=[h, w], axis=2))(
            x_cat_conv_relu)
        x_cat_conv_split_h = Lambda(lambda x: K.permute_dimensions(x, [0, 2, 1, 3]))(x_cat_conv_split_h)
        x_cat_conv_split_h = Conv2D(channel, kernel_size=1, strides=1, use_bias=False,
                                    name="ca_block_conv2_" +str(uuid.uuid4())+ str(name))(x_cat_conv_split_h)
        x_cat_conv_split_h = Activation('sigmoid')(x_cat_conv_split_h)

        x_cat_conv_split_w = Conv2D(channel, kernel_size=1, strides=1, use_bias=False,
                                    name="ca_block_conv3_" + str(uuid.uuid4())+str(name))(x_cat_conv_split_w)
        x_cat_conv_split_w = Activation('sigmoid')(x_cat_conv_split_w)

        output = multiply([input_feature, x_cat_conv_split_h])
        output = multiply([output, x_cat_conv_split_w])
        return output

    def SKBlock1(self,input_tensor, filters):
        # 分支1: 3x3卷积
        # branch1 = SeparableConv2D(filters, 3, padding='same', activation='relu')(input_tensor)

        branch2 = SeparableConv2D(filters, 5, padding='same', activation='relu')(input_tensor)
        # 分支2: 5x5卷积（等效两个3x3）
        branch3 = SeparableConv2D(filters, 7, padding='same', activation='relu')(input_tensor)

        # 注意力融合
        merged = Concatenate()([branch2,branch3])
        gap = GlobalAvgPool2D()(merged)
        fc = Dense(filters//8, activation='relu')(gap)
        attn = Dense(filters * 2, activation='softmax')(fc)  # 动态权重
        attn_b2, attn_b3 = tf.split(attn, num_or_size_splits=2, axis=1)
        output = Multiply()([branch2, attn_b2])+Multiply()([branch3, attn_b3])

        # 残差连接
        shortcut = Conv2D(filters, 1)(input_tensor) if input_tensor.shape[-1] != filters else input_tensor
        return tf.keras.layers.Add()([output, shortcut])

    def SKBlock(self,input_tensor, filters):
        # 分支1: 3x3卷积
        # branch1 = SeparableConv2D(filters, 3, padding='same', activation='relu')(input_tensor)

        branch2 = SeparableConv2D(filters, 5, padding='same', activation='relu')(input_tensor)
        # 分支2: 5x5卷积（等效两个3x3）
        branch3 = SeparableConv2D(filters, 7, padding='same', activation='relu')(input_tensor)

        # 注意力融合
        merged = Concatenate()([branch2,branch3])
        gap = GlobalAvgPool2D()(merged)
        fc = Dense(filters//8, activation='relu')(gap)
        attn = Dense(filters * 2, activation='softmax')(fc)  # 动态权重
        attn_b2, attn_b3 = tf.split(attn, num_or_size_splits=2, axis=1)
        output = Multiply()([branch2, attn_b2])+Multiply()([branch3, attn_b3])
        # 残差连接
        shortcut = Conv2D(filters, 1)(input_tensor) if input_tensor.shape[-1] != filters else input_tensor
        return tf.keras.layers.Add()([output, shortcut])
    def dynamic_weight_fusion(self, base1,scale1,base2, scale2,base3,scale3,base4,scale4):
        # 动态权重生成（双层Dense）
        weights = layers.Concatenate()([base1,scale1,base2, scale2,base3,scale3,base4,scale4])
        # weights = BatchNormalization()(weights)
        weights = layers.Dense(256, activation='relu')(weights)
        weights = layers.Dense(8, activation='softmax')(weights)
        # 加权融合
        weighted_base1 = layers.Multiply()([base1, weights[:, 0:1]])
        weighted_scale1 = layers.Multiply()([scale1, weights[:, 1:2]])
        weighted_base2 = layers.Multiply()([base2, weights[:, 2:3]])
        weighted_scale2 = layers.Multiply()([scale2, weights[:, 3:4]])
        weighted_base3 = layers.Multiply()([base3, weights[:, 4:5]])
        weighted_scale3 = layers.Multiply()([scale3, weights[:, 5:6]])
        weighted_base4 = layers.Multiply()([base4, weights[:, 6:7]])
        weighted_scale4 = layers.Multiply()([scale4, weights[:, 7:8]])
        return layers.Add()([weighted_base1, weighted_scale1,weighted_base2,weighted_scale2,weighted_base3,weighted_scale3,weighted_base4,weighted_scale4])

    def create_multi_directory_model(self):
        base_model = ResNet50(include_top=False, weights='imagenet', input_shape=(224, 224, 3))
        x = base_model.output
        x = GlobalAveragePooling2D()(x)
        predictions = Dense(10, activation='softmax')(x)
        model = Model(inputs=base_model.input, outputs=predictions)
        model.summary()
        return model
    # def create_multi_directory_model(self):
    #     """创建四输入预训练模型，支持参数更新后的最终输出"""
    #     # 定义四个输入
    #     inputs1 = keras.Input(shape=(224, 224, 3), name="input_a")
    #     inputs2 = keras.Input(shape=(224, 224, 3), name="input_b")
    #     inputs3 = keras.Input(shape=(224, 224, 3), name="input_c")
    #     inputs4 = keras.Input(shape=(224, 224, 3), name="input_d")
    #
    #     # 创建EfficientNet基础模型
    #     base_model = keras.applications.EfficientNetB0(
    #         include_top=False,
    #         weights='imagenet'
    #     )
    #     # 解冻基础模型权重以便更新
    #     base_model.trainable = True
    #
    #     # 创建中间层模型，用于获取block1a_activation层输出
    #     intermediate_model = keras.Model(
    #         inputs=base_model.input,
    #         outputs=base_model.get_layer('block1a_activation').output
    #     )
    #
    #     # 依次处理四个输入，获取各自原始输出
    #     print("正在处理第一个输入...")
    #     inter_features1 = intermediate_model(inputs1)
    #     final_features1 = base_model(inputs1)
    #
    #     print("正在处理第二个输入...")
    #     inter_features2 = intermediate_model(inputs2)
    #     final_features2 = base_model(inputs2)
    #
    #     print("正在处理第三个输入...")
    #     inter_features3 = intermediate_model(inputs3)
    #     final_features3 = base_model(inputs3)
    #
    #     print("正在处理第四个输入...")
    #     inter_features4 = intermediate_model(inputs4)
    #     final_features4 = base_model(inputs4)
    #
    #     # 合并特征用于最终输出
    #     x1 = mobilenet_block(inter_features1, filters=64, kernel_size=7, strides=1)
    #     x2 = mobilenet_block(inter_features2, filters=64, kernel_size=7, strides=1)
    #     x3 = mobilenet_block(inter_features3, filters=64, kernel_size=7, strides=1)
    #     x4 = mobilenet_block(inter_features4, filters=64, kernel_size=7, strides=1)
    #
    #     # EfficientNet Block
    #     x1 = efficientnet_block(x1, filters=128, kernel_size=3, strides=1, expand_ratio=6)
    #     x1 = efficientnet_block(x1, filters=128, kernel_size=3, strides=2, expand_ratio=6)
    #
    #     x2 = efficientnet_block(x2, filters=128, kernel_size=3, strides=1, expand_ratio=6)
    #     x2 = efficientnet_block(x2, filters=128, kernel_size=3, strides=2, expand_ratio=6)
    #
    #     x3 = efficientnet_block(x3, filters=128, kernel_size=3, strides=1, expand_ratio=6)
    #     x3 = efficientnet_block(x3, filters=128, kernel_size=3, strides=2, expand_ratio=6)
    #
    #     x4 = efficientnet_block(x4, filters=128, kernel_size=3, strides=1, expand_ratio=6)
    #     x4 = efficientnet_block(x4, filters=128, kernel_size=3, strides=2, expand_ratio=6)
    #
    #     # ConvNeXt Block
    #     x1 = convnext_block(x1, filters=256)
    #     x1 = convnext_block(x1, filters=256)
    #     x1 = self.ca_block(x1)
    #     x1 = self.SKBlock(x1, 256)
    #
    #     x2 = convnext_block(x2, filters=256)
    #     x2 = convnext_block(x2, filters=256)
    #     x2 = self.ca_block(x2)
    #     x2 = self.SKBlock(x2, 256)
    #
    #     x3 = convnext_block(x3, filters=256)
    #     x3 = convnext_block(x3, filters=256)
    #     x3 = self.ca_block(x3)
    #     x3 = self.SKBlock(x3, 256)
    #
    #     x4 = convnext_block(x4, filters=256)
    #     x4 = convnext_block(x4, filters=256)
    #     x4 = self.ca_block(x4)
    #     x4 = self.SKBlock(x4, 256)
    #
    #     x1 = layers.Conv2D(1280, kernel_size=1, padding='same')(x1)
    #     x2 = layers.Conv2D(1280, kernel_size=1, padding='same')(x2)
    #     x3 = layers.Conv2D(1280, kernel_size=1, padding='same')(x3)
    #     x4 = layers.Conv2D(1280, kernel_size=1, padding='same')(x4)
    #
    #     # 分类头
    #     x1 = layers.GlobalAveragePooling2D()(x1)
    #     x2 = layers.GlobalAveragePooling2D()(x2)
    #     x3 = layers.GlobalAveragePooling2D()(x3)
    #     x4 = layers.GlobalAveragePooling2D()(x4)
    #
    #     # 全局平均池化
    #     gap1 = layers.GlobalAveragePooling2D()(final_features1)
    #     gap2 = layers.GlobalAveragePooling2D()(final_features2)
    #     gap3 = layers.GlobalAveragePooling2D()(final_features3)
    #     gap4 = layers.GlobalAveragePooling2D()(final_features4)
    #
    #     scale1 = multiply([x1, gap1])
    #     scale2 = multiply([x2, gap2])
    #     scale3 = multiply([x3, gap3])
    #     scale4 = multiply([x4, gap4])
    #     x1 = self.dynamic_weight_fusion(gap1,scale1,gap2,scale2,gap3,scale3,gap4,scale4)
    #
    #     predictions = Dense(10, activation="softmax", kernel_initializer='he_normal')(x1)
    #     model = tensorflow.keras.Model(inputs=[inputs1, inputs2,inputs3,inputs4], outputs=predictions)
    #     return model